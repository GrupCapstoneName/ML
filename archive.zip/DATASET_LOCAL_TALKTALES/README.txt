KODE SPEAKER
LUTHFI=A
DANDI=B
NABHAN=C
RAFLI=D
NIKO=E

KODE PERCAKAPAN
101 = Please give us a little more time
102 = 12_4_Timun_Mas_you_must_leave_now_Take_this_bundle_Inside_are_items_that_can_help_you_escape_from_the_raksasa\
103 = 12_7_Thank_goodness_you_are_safe_Timun_Mas_Now_we_can_live_in_peace
104 = 13_9_Yes_and_also_make_sure_dinner_is_ready_when_we_get_back
105 = 13_11_I_lost_my_mother's_clothes_Grandma_If_I_go_home_without_them_I'll_be_scolded
106 = 13_15_I_lost_my_clothes_Hurry_up_and_return_them_I_don't_have_time_for_this_nonsense
107 = 13_17_How_could_this_happen
